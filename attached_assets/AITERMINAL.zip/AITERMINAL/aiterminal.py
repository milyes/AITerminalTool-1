import os
import time

def loading_animation(text="Chargement AITERMINAL", duration=3):
    for i in range(duration):
        print(f"\r{text}{'.' * (i % 4)}", end="")
        time.sleep(0.5)
    print("\n[+] Chargement terminé.")

def main():
    os.system('clear' if os.name == 'posix' else 'cls')
    print("""
     ___    ___ ________  ________  ________  ________  ________  ___       ___     
    |\  \  /  /|\   __  \|\   __  \|\   ____\|\   ____\|\   __  \|\  \     |\  \    
    \ \  \/  / | \  \|\  \ \  \|\  \ \  \___|\ \  \___|\ \  \|\  \ \  \    \ \  \   
     \ \    / / \ \   __  \ \  \\\  \ \  \    \ \  \    \ \   __  \ \  \    \ \  \  
      \/  /  /   \ \  \ \  \ \  \\\  \ \  \____\ \  \____\ \  \ \  \ \  \____\ \  \ 
     __/  / /      \ \__\ \__\ \_______\ \_______\ \_______\ \__\ \__\ \_______\ \__\
    |\___/ /        \|__|\|__|\|_______|\|_______|\|_______|\|__|\|__|\|_______|\|__|
    \|___|/                                                                           
    """)
    loading_animation()

    print("Bienvenue sur AITERMINAL !")
    print("Tapez 'help' pour voir les commandes disponibles.")

    while True:
        cmd = input("> ").strip().lower()
        if cmd == "help":
            print("Commandes disponibles: help, generate_module, connect_api, system_control, exit")
        elif cmd == "generate_module":
            print("Génération automatique de module IA...")
        elif cmd == "connect_api":
            print("Connexion à l'API IA...")
        elif cmd == "system_control":
            print("Contrôle système activé...")
        elif cmd == "exit":
            print("Fermeture d'AITERMINAL.")
            break
        else:
            print("Commande inconnue, tapez 'help'.")

if __name__ == "__main__":
    main()
