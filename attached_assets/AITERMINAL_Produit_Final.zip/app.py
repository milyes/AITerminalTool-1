from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
import shutil
from pathlib import Path
import uuid
import cv2
import numpy as np

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")

UPLOAD_DIR = Path("static/uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

@app.post("/upload-image/")
async def upload_image(file: UploadFile = File(...)):
    extension = file.filename.split(".")[-1]
    img_id = f"{uuid.uuid4()}.{extension}"
    img_path = UPLOAD_DIR / img_id

    with img_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Analyse IA basique : détection de contours
    image = cv2.imread(str(img_path))
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)

    avatar_path = UPLOAD_DIR / f"avatar_{img_id}"
    cv2.imwrite(str(avatar_path), edges)

    return JSONResponse(content={
        "filename": img_id,
        "message": "Image analysée et avatar IA généré.",
        "avatar_path": f"/static/uploads/avatar_{img_id}"
    })

@app.get("/")
def index():
    html_path = Path("index.html")
    return HTMLResponse(content=html_path.read_text(), status_code=200)
